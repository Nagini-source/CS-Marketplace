package com.designops.model;

import java.util.List;

public class Usage {
	
	private List<RichTextArray> richTextArray;

	public List<RichTextArray> getRichTextArray() {
		return richTextArray;
	}

	public void setRichTextArray(List<RichTextArray> richTextArray) {
		this.richTextArray = richTextArray;
	}
	
	

}
