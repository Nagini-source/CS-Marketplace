package com.designops.model;

import java.util.List;

public class Update {

	private List<Updates> updates;

	public List<Updates> getUpdates() {
		return updates;
	}

	public void setUpdates(List<Updates> updates) {
		this.updates = updates;
	}
	
	
}
