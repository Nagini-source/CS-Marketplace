package com.designops.model;

public class TenantColors {

	private String tenantName;
	
	private String tenantColor;

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public String getTenantColor() {
		return tenantColor;
	}

	public void setTenantColor(String tenantColor) {
		this.tenantColor = tenantColor;
	}
	
	
}
