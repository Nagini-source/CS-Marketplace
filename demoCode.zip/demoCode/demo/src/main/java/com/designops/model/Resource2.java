package com.designops.model;

public class Resource2 {
	
	private String resourceName;
	
	private String linkLocation;
	


	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getLinkLocation() {
		return linkLocation;
	}

	public void setLinkLocation(String linkLocation) {
		this.linkLocation = linkLocation;
	}


	
	
	

}
