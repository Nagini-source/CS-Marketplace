package com.designops.model;

public class PreviewImage {
	
	
	private String previewImage;
	
	private String fileName;
	
	private String capImage;

	public String getPreviewImage() {
		return previewImage;
	}

	public void setPreviewImage(String previewImage) {
		this.previewImage = previewImage;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getCapImage() {
		return capImage;
	}

	public void setCapImage(String capImage) {
		this.capImage = capImage;
	}
	
	

}
